Prerequisites
- nodejs

To build locally, navigate into subfolder website and execute
- npm install
- npm run start
