var searchData=
[
  ['id_5ftype',['id_type',['../namespacefasttext.html#a6778f74ca8c360ba917216cb7fcbf497',1,'fasttext']]]
];
