var searchData=
[
  ['ksub_5f',['ksub_',['../classfasttext_1_1ProductQuantizer.html#afa68c0f82fab09a93c2024a4dceecdf7',1,'fasttext::ProductQuantizer']]]
];
